# Trade over Aid atlas v0.3: October continuation and intake audit

**Research snapshot: 15 October 2026. Financial source cutoff: 30 June 2026.**

## Bottom line

All 77 previously documented financial country–program relationships received a source-record date audit and a national product/application-route check. None was upgraded to **October-confirmed continuation**. This means confirmation was not obtained, not that financing stopped. Six priority countries also received country-rule and application-route checks. Public routes and documents are established; actual intake acceptance, available balances, disbursements and subsequent changes are not.

The six priority countries are Costa Rica, Guatemala, Kenya, Nauru (also indexed as Naoero), Pakistan and the Philippines. They have 18 of the prior financial relationships, based on 61 observations across five of the six countries. Nauru has no qualifying attributed observation in the existing financial slice; that is not a global finance-absence finding.

## Open the products

Open `Trade_Over_Aid_Atlas.html` in a modern browser. All data and map geometry are embedded. Normal exploration needs no internet; source links do. Browser security settings can restrict local HTML. This environment blocked direct file launch; the complete document was tested in a clean browser page via in-memory loading. No hosted deployment or local-file launch success is claimed.

`Trade_Over_Aid_Briefing_Page.pdf` is a one-page landscape briefing. Its PNG is provided for insertion into another report. The PDF and explorer use the same data, but the static briefing is explicitly a six-country, eight-program selection; it is not the full country-program census.

## What changed

| Review | Result | Interpretation |
|---|---:|---|
| Prior finance relationships audited | 77 | 206 source observations, not 206 distinct deals |
| EXIM observations | 88 | 72 recorded windows span 15 October; 11 elapsed; 5 incomplete or inapplicable |
| DFC observations | 118 | Portfolio classification remains dated 30 June |
| October continuation confirmations obtained | 0 | Unresolved, not inactive |
| Priority financial relationships | 18 | 61 observations in five countries |
| Country–finance intake assessments | 54 | Six countries × nine named tools; actual acceptance untested |
| Gold Key / Partner Search relationships checked | 12 | One historically dated report; one delivered but undated case; ten unresolved |

### Finance evidence

The public DFC database still identifies a 30 June 2026 cutoff and describes its quarterly update cadence. Commitments are not disbursements. [S45]

The EXIM date audit applies the current data dictionary, which defines an expiration field for insurance and guarantees, not direct-loan maturity. A window spanning October cannot establish that the instrument remained unchanged, was used, or was not cancelled. An elapsed window cannot establish that covered receivables, underlying loans or program activity ceased. [S44]

There are 24 country–program pairs with at least one recorded window spanning the snapshot, four with only elapsed mapped windows, one project-review-risk flag, and 48 otherwise unresolved pairs. Mixed old/renewal records remain together rather than classifying an entire country–tool relationship as inactive. Exact source identifiers and dates are in the observation audit.

**Reko Diq:** the sponsor's 2 April 2026 statement reports slowed development and a review including financing expected to run through mid-2027. This is material context for the prior EXIM authorization, not confirmation of an operative October loan or an EXIM cancellation. The direct-loan expiration field is not converted to a maturity date. [S51]

**PMIC date conflict:** the page URL/site metadata is January 2026, but the body dates the guarantee signing to 11 July 2024. The agreement is not treated as a 2026 renewal. [S55]

### Country-level intake findings

The following EXIM entries are **routine cover**, not approval of a new borrower. Columns within each string are up to one year / one to seven years / over seven years. All country notes and stated exceptions apply. [S41–S42]

| Country | EXIM public | EXIM private | Notes | DFC evidence |
|---|---|---|---|---|
| Costa Rica | Y/Y/Y | Y/Y/Y | 6b | Possible-support listing and agreement document |
| Guatemala | Y/Y/Y | Y/Y/Y | 6b | Possible-support listing and agreement document |
| Kenya | N/N/N | Y/N/N | 1, 10, 11b, 13 | Possible-support listing and agreement document |
| Nauru | N/N/N | N/N/N | 13 | Possible-support listing and agreement document |
| Pakistan | Y/Y/Y | Y/Y/Y | 1, 4, 15a, 15b | Possible-support listing and agreement document |
| Philippines | Y/Y/Y | Y/Y/Y | 4 | Possible-support listing and agreement document |

EXIM public application forms/entry points and all six mapped DFC asset-class application routes were checked. A DFC portal link produced a rendering error. No accounts were created, applications submitted, agencies contacted, or queue/capacity tests performed. DFC directory links and first PDF pages establish listed agreement documents, not a complete legal opinion on treaty amendments, continued effect or the eligibility of a specific project. [S43, S46–S50, S58–S70]

Kenya is not generally “open”: routine cover is private short-term only. Nauru is not universally excluded from U.S. finance: EXIM is routine off-cover, while DFC lists a conditional country route and agreement. No legal-prohibition or automatic-approval inference is made.

### Matchmaking delivery

Costa Rica's Digital Harvest **IPS plus Virtual Introductions** case is described in a Commerce report published 8 September 2025. Exact service dates are unknown, so the report supplies a latest-known historical bound, not a fabricated meeting date or 2026 continuation. [S52]

Kenya's Astec case explicitly describes Gold Key meetings and a dealer contract, but no defensible absolute publication or service date was recovered. Occurrence is substantiated; timing remains unknown. A relative-age repost and website footer are not service dates. The ten unnamed additional markets are not country-coded. [S53]

The remaining ten country–service pairs have no dated, instrument-attributable delivery established in this targeted pass. National menus, website country selectors and generic Commercial Service success references are not treated as specific Gold Key/IPS delivery. The Philippines All Good Products lead is retained separately because instrument and date attribution were not established. [S71–S75]

## Three independent explorer views

**Activity evidence:** F = financing recorded by 30 June; D = dated reported delivery; H = delivery described in a historical pre-2026 report; solid dot = prior verified open procurement; diamond = announced; ? = unresolved; dash = domestic project-location axis. Kenya Gold Key remains ? because its timing is unresolved, while its detail panel acknowledges the delivered service.

**Published services:** O = an official country-specific service route. An asterisk marks a pre-2026 publication. This is not delivered activity, current staffing, price or tested acceptance.

**October finance check:** W = at least one recorded effective/expiration window spans 15 October; E = all mapped insurance/guarantee rows for that relationship have elapsed windows; ! = the Reko Diq project-review context; ? = unresolved dates or June-only portfolio status. None certifies October continuation. The detail panel separates dates, counterparty evidence, routine cover and application routes.

## Scope and unresolved limits

The roster is **not refreshed in this version**. The v0.2 reconstruction has 47 indexed names and three earlier-only names. The 50-country union is a research population, not a certified current membership count. South Africa, Sri Lanka and Sudan are not classified as withdrawals. Original access and fragment receipts are retained. [S01–S02, S27]

The base matrix remains 249 country/territory units × 62 named tools. Prior 50 × 9 financial screening yielded 77 relationships and 373 without qualifying attributed records. Another 162 DFC cohort rows remain outside named-product counts: 71 ambiguous Finance and 91 Legacy. Frameworks and duplicate project identifiers are preserved. No dollar total, project count, impact ranking, full operating census, causal trade-for-aid substitution or government certification is claimed.

Raw finance rows are reused unchanged from v0.2 and its actual v0.8 workbook inputs. Raw endpoint retrieval failed in this environment. Public sources were read through web retrieval; new `source_review_receipts.json` entries are analyst paraphrases with URLs, dates and retrieval references, not full-page archives or raw snapshots. Prior procurement, service-menu, roster, eligibility and presence evidence is inherited unless an explicit v0.3 update is recorded.

Targeted counterparty searches were prioritized in the six countries. “77 audited” does **not** mean 77 agency/client confirmations or complete borrower-by-borrower research. The record-date audit covers every financial observation; targeted counterparty searches and their non-findings are separately logged.

## Files

- `data/atlas.json`: embedded-data master.
- `data/continuation_observation_audit.csv`: all 206 records with identifiers, dates, audit class and limitations.
- `data/finance_continuation_pairs.csv`: 77 relationship-level date/risk dispositions.
- `data/country_intake.csv`, `finance_intake.csv`, `product_routes.csv`: six-country terms, 54 country/tool assessments and nine national product routes.
- `data/matchmaking_delivery.csv`, `review_log.csv`: 12 delivery checks and targeted searches.
- `data/country_program_activity.csv`: full 15,438-cell export with independent October and intake fields.
- Other data files preserve the original observations, unallocated evidence, source register and published services.
- `source/`: immutable v0.2 atlas/template plus prior workbook and its extracted JSON, copied without edits.
- `evidence/`: new source-review and failed-retrieval receipts; prior roster and finance retrieval records.
- `qa/`: current data/browser results, final screenshots, grayscale check, searchable PDF text and reproducibility result.
- `src/`: complete prepare/build/render/validation scripts. Source records and normalization decisions are explicit in `prepare_data.py`.

## Rebuild and validate

The data/HTML build uses the Python standard library. PDF/browser checks require the dependencies in `requirements-render.txt` and Chromium. The implementation stays in Python because this prototype is an existing Python/HTML build; no statistical model or language conversion is required.

```sh
python src/prepare_data.py
python src/upgrade_template.py
python src/build.py
# Rendering environment only:
python -m pip install -r requirements-render.txt
python -m playwright install chromium
python src/validate_render.py
```

`CHROMIUM_PATH` can point to an installed Chromium executable. Without it, the validator uses system Chromium when present, then Playwright's installed browser. Rebuilding does not automatically refresh any public source. Review changed source documents before editing evidence; preserve the distinction between unknown and confirmed negative.

Data and HTML hashes were reproduced exactly. PDF creation timestamps can vary, so PDF byte identity is not asserted. Current validation has **44/44 data checks and 80/80 browser/PDF checks**. These establish transformation/UI consistency and layout, not the truth of unverified October financial status. Final print, desktop, mobile and grayscale outputs were visually reviewed.

## Remaining work

Obtain source-specific October status or amendment records for existing instruments; verify actual intake and available capacity directly with the relevant agencies; recover absolute dates for Kenya's case and dated delivery for the remaining service pairs. Any agency outreach should be separately authorized. No outreach has been sent.
