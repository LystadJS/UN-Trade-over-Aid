# Trade Over Aid | Agency verification requests v0.4

**Prepared 15 October 2026. DRAFTS ONLY. Nothing sent.**

This package prepares eight source-linked research inquiries against the atlas v0.3 evidence gaps. It does not submit an application, request commissioned services, create drafts in a mail account, initiate FOIA proceedings or authorize fees. It does not update the atlas or establish any new October continuation/intake finding.

## Start here

- **Agency_Verification_Requests_v0_4.docx:** a ten-page editable document containing the routing overview, evidence protocol and eight agency/country drafts.
- **Agency_Verification_Response_Tracker_v0_4.xlsx:** the nine-sheet master response tracker. Yellow cells are intended for replies; original identifiers and source facts remain separate. The dashboard calculates counts from the underlying tables.
- **drafts/:** eight standalone plain-text letters, including suggested recipient, subject, linked sources, precise questions and sender placeholders.
- **annexes/:** recipient-specific CSV response templates. Select only the folder matching the request ID. The all-agency master workbook is not intended to be distributed wholesale to each recipient.

Before any later use outside ChatGPT, replace the bracketed sender identity and reply address. Published recipient addresses are routing suggestions, not tested mailboxes or confirmations of current individual responsibility. No sender affiliation has been assumed.

## What is covered

| Request | Financial observations | Separate intake questions | Other reviews |
|---|---:|---:|---|
| VR-EXIM-01 | 88, representing 30 country/tool pairs | 43 | Reko Diq, renewal chains and date-field exceptions |
| VR-DFC-01 | 118, representing 47 country/tool pairs | 70 | Optional classification of 162 additional Finance/Legacy rows |
| Six VR-CS-* country drafts | Not applicable | Included in each service review | 12 Gold Key/International Partner Search reviews |

The six priority countries are Costa Rica, Guatemala, Kenya, Nauru, Pakistan and the Philippines. There are 61 mapped financial observations in the priority group. These records and the 54 priority country/product intake combinations are placed first.

The 113 finance intake questions are the union of the 77 documented country/tool pairs and 54 priority combinations, minus 18 overlaps. They are questions, not newly verified available programs. The 162 optional DFC classification rows are separate from the 206 mapped observations. A DFC source row is not necessarily a distinct project.

## Evidence and routing qualifications

The frozen financial observations remain based on the June 30, 2026 source snapshot. This pass did not obtain a fresh raw financial download. It checked published routing references and selected public case pages, then converted the established gaps into record-specific questions. Prior facts are presented as evidence to be confirmed, not current agency answers.

All requests specify **15 October 2026** as the cutoff and ask for later changes to be dated separately. Continuation of an existing financial instrument, actual project operations, utilization and acceptance of new applications are separate questions. Matchmaking requests separate publication dates, actual service dates, work underway on the cutoff and completed delivery during October 1–15.

Nauru-to-Suva routing is **provisional**. The draft asks the published Fiji office to confirm or refer the responsible program unit. Suva diplomatic accreditation does not establish Gold Key or Partner Search delivery in Nauru. Other contacts are published general/office or named routing leads; mailbox delivery and individual incumbency were not tested.

The source register includes inherited `S*` sources and new `R*` routing/case references. `evidence/routing_review_receipts.json` contains analyst review notes, access mode and URLs, not authenticated complete webpage archives. Hyperlink checks test consistency with the source register, not universal URL availability.

## Identifier and response discipline

EXIM official identifiers and DFC project numbers are retained as text. `DFC-ROW-*` is an inherited snapshot locator, not a durable agency identifier. `VR-*`, `IN-*` and `MM-*` are internal request/review keys. No official matchmaking service-case IDs have been invented. The annexes request public or anonymized agency references when available.

Return the matching CSV or keyed text with identifiers unchanged. Record a dated source or attributable official confirmation, responding unit, the status effective date, any qualifications and permission to cite. Unknown, declined and non-disclosable responses remain distinct from inactivity. A closed instrument does not establish absence of an entire program. No confidential client material is requested.

Response-state fields measure receipt/completeness only. Marking a reply “Complete” does not automatically confirm activity. No automatic atlas update, mail action or status inference is embedded in the workbook.

## Package organization

`data/` contains complete record-specific questions, the intake/service registers, question bank, request content and source register. `provenance/` contains the frozen input CSVs, original atlas README and SHA-256 receipt for the source archive. `src/` contains preparation, document, workbook and validation scripts. `validation/` contains machine-readable check results and visual-review notes.

## Rebuild

Run from an environment with Python 3, `python-docx` and the provided `artifact_tool` spreadsheet runtime:

```sh
python src/prepare_requests.py
python src/build_document.py
python src/build_workbook.py
python src/validate_package.py
```

`prepare_requests.py` uses the included `provenance/` inputs. It does not refresh web evidence. Rebuilding resets response templates to their original unsent, unanswered state, so preserve any later agency replies before running it. The workbook builder requires the supplied artifact_tool environment; it is not represented as a generally available package install. Workbook preview images are written outside the deliverable folder in the original `/mnt/data` runtime. DOCX visual rendering used the environment's DOCX rendering helper; that external helper is not bundled.

The preparation rerun reproduced all 28 data, draft and annex exports with identical SHA-256 hashes. Document and workbook binary hashes are not claimed to be invariant between builds. Regenerate `manifest.sha256` after any intentional modification.

## Validation and remaining limits

- 33/33 data checks passed.
- 27/27 document/workbook structural checks passed, including exact text IDs, correct dashboard formula caches, blank replies, source-link mapping and no macros or external workbook connections.
- All ten rendered document pages were visually inspected. Workbook dashboard and representative record previews were inspected; all nine sheets were structurally checked.
- No cached spreadsheet formula errors were found. ZIP integrity and manifest checks are recorded separately.

These checks validate the request package, not the underlying October operational claims. Agency confirmation remains pending. No agency has been contacted, no message has been sent and no mail-account draft has been created.
