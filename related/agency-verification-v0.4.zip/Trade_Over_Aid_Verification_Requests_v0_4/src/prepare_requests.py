"""Build unsent, source-linked verification requests from the frozen atlas v0.3.
No email client, authentication, submission, or other network write is used.
"""
from pathlib import Path
import csv, json, hashlib, shutil, collections, re
ROOT = Path(__file__).resolve().parents[1]
# Included provenance CSVs are the portable rebuild inputs. This path is only a fallback
# for first-time builds in the original workspace. No network refresh is attempted.
PRIOR = Path('/mnt/data/prior_v03/Trade_Over_Aid_Prototype_v0_3')
AS_OF = '2026-10-15'
PRIORITY = ['CR','GT','KE','NR','PK','PH']

def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as f: return list(csv.DictReader(f))
def write_csv(path, rows, fields=None):
    if not rows and not fields: raise ValueError('An empty export needs an explicit schema')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0])); w.writeheader(); w.writerows(rows)
def dump(path, obj): path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def load(name): return read_csv(ROOT/'provenance'/f'{name}.csv')

for d in ['provenance','data','drafts','annexes','validation','evidence']: (ROOT/d).mkdir(exist_ok=True)
files=['finance_observations','continuation_observation_audit','finance_continuation_pairs','finance_intake','country_intake','matchmaking_delivery','unallocated_finance','programs','country_roster','sources','product_routes','unallocated_activity_reports']
for n in files:
    dest=ROOT/'provenance'/f'{n}.csv'
    if not dest.exists(): shutil.copy2(PRIOR/'data'/f'{n}.csv',dest)
if not (ROOT/'provenance'/'atlas_v03_README.md').exists(): shutil.copy2(PRIOR/'README.md',ROOT/'provenance'/'atlas_v03_README.md')
source_list=load('sources')
sources={s['id']:s for s in source_list}
new_sources=[
('R01','USAGov: EXIM public contact','https://www.usa.gov/agencies/export-import-bank-of-the-united-states','page_read','Lists info@exim.gov. Public routing address, not confirmed ownership of a specific instrument.','turn848962view6'),
('R02','Data.gov: EXIM authorization dataset contact metadata','https://catalog.data.gov/dataset/authorizations-from-10-01-2006-thru-06-30-2025','page_read','Dataset contact names the Office of Chief Financial Officer and lists foia@exim.gov. The FOIA mailbox is NOT selected or copied; no formal records request is being initiated.','turn248866view0'),
('R03','DFC transaction-data contact','https://www.dfc.gov/our-impact/transaction-data','page_read','Lists data@dfc.gov for Open Data questions.','turn327361view3'),
('R04','DFC general contact','https://www.dfc.gov/who-we-are/contact','search_result_read','Lists info@dfc.gov for general inquiries; used as a routing copy in the unsent DFC draft.','turn627058search9'),
('R05','Commerce Costa Rica country contacts','https://www.trade.gov/costa-rica-contact-us','page_read','Lists Clint.Brewer@trade.gov and Roy.Fernandez@trade.gov. Names are published routing leads; incumbency and mailbox delivery were not independently tested.','turn248866view2'),
('R06','Commerce Guatemala country contacts','https://www.trade.gov/guatemala-contact-us','page_read','Lists Jessica.Gordon@trade.gov. Incumbency and mailbox delivery were not independently tested.','turn848962view2'),
('R07','Commerce Kenya country contacts','https://www.trade.gov/kenya-contact-us','search_result_read','Lists Office.Nairobi@trade.gov. Shared office mailbox preferred over differing named-officer listings.','turn147726search0'),
('R08','Commerce Pakistan published team mailbox','https://www.trade.gov/market-intelligence/pakistan-franchising-payment-rules','page_read','Dated 25 May 2026; lists office.pakistan@trade.gov for the country team. Only the contact information is used.','turn848962view4'),
('R09','Commerce Philippines country contacts','https://www.trade.gov/philippines-contact-us','search_result_read','Lists businessphilippines@trade.gov. Mailbox delivery was not tested.','turn147726search9'),
('R10','Commerce Fiji / Suva contact','https://www.trade.gov/fiji-contact-us','page_read','Lists office.fiji@trade.gov. Used only as a proposed referral for Nauru; Nauru program responsibility remains unverified.','turn848962view3'),
('R11','U.S. Embassy Suva accreditation information','https://fj.usembassy.gov/embassy-fact-sheets/','official_index_excerpt_only','Indexed official text identifies Suva accreditation to Nauru. Diplomatic accreditation does not establish responsibility for Gold Key or IPS.','turn327361search7'),
('R12','Commerce Digital Harvest case refreshed','https://www.trade.gov/feature-article/attention-exporters-find-right-market-match-us-commercial-service','page_read','8 September 2025 publication; explicit IPS plus Virtual Introductions. Exact service dates still unestablished.','turn848962view0'),
('R13','Commerce Astec Kenya case refreshed','https://www.trade.gov/success-story/south-dakota-business-extends-reach-africa-kenya','page_read','Explicit Gold Key delivery and dealership outcome; no absolute publication or service date recovered.','turn848962view1'),
('R14','DFC active-projects cutoff refreshed','https://www.dfc.gov/what-we-do/active-projects','page_read','Page still states 30 June 2026 and approximately 45-day quarterly posting lag. No raw portfolio was downloaded in this correspondence-preparation pass.','turn848962view5'),
('R15','EXIM contact center','https://www.exim.gov/contact','search_result_read','Lists 800-565-3946 and 202-565-3946. No call was made.','turn627058search0'),
]
for sid,title,url,access,note,ref in new_sources:
    sources[sid]={'id':sid,'title':title,'url':url,'published':'','retrieved':AS_OF,'kind':'official_primary','access':access,'note':note,'web_receipt':ref}
write_csv(ROOT/'data'/'source_register.csv',list(sources.values()))
dump(ROOT/'evidence'/'routing_review_receipts.json',{
    'reviewed':AS_OF,'receipt_type':'Analyst source-review notes, not full-page archives',
    'scope':'Read-only public routing and case checks. No mail accounts accessed; no requests sent.',
    'sources':[sources[x[0]] for x in new_sources]})

programs={r['id']:r for r in load('programs')}
countries={r['code']:r['name'] for r in load('country_roster')}
countries['NR']='Nauru (Naoero)'
obs=load('finance_observations'); audit={r['observation_id']:r for r in load('continuation_observation_audit')}
pairs=load('finance_continuation_pairs'); mm=load('matchmaking_delivery'); unc=load('unallocated_finance')
intake_old={(r['country'],r['program']):r for r in load('finance_intake')}
country_terms={r['country']:r for r in load('country_intake')}
routes={r['program']:r for r in load('product_routes')}

questions={
'EX-STATUS': 'For each listed source ID, confirm the authorization, agreement, policy or guarantee state at 15 October 2026. Distinguish authorization only, signed but not effective, effective but unused, utilized, suspended, cancelled, expired with residual exposure, and closed. Provide the controlling action or confirmation date and publicly citable evidence.',
'EX-SPAN': 'The recorded effective/expiration window spans 15 October 2026. Was the instrument actually in force on that date? Identify any intervening cancellation, suspension, amendment or replacement; a scheduled date window alone is not confirmation.',
'EX-ELAPSED': 'The recorded window ends before 15 October 2026. Was the record renewed, extended, replaced or closed? Provide successor IDs and effective dates, and distinguish new-business availability from residual covered receivables, guarantees or claims.',
'EX-MISSING': 'An effective or expiration date is missing. Supply the operative date or explain that the field is not applicable; identify an alternative source for instrument status. Do not infer effectiveness from authorization alone.',
'EX-LOAN': 'For Reko Diq authorization 07099993XXAA01, confirm whether the loan agreement was executed, became effective, had any drawdown, or was revised/suspended/cancelled by 15 October 2026. Explain the meaning of raw ExpirationDate=2029-06-30; it has not been interpreted as maturity. Reconcile with the sponsor review announced 2 April 2026.',
'EX-RENEWAL': 'For Fly Ace IDs 09782442ST1002 and 09782442ST1003, confirm whether these are predecessor/successor policy records, their distinct coverage periods and any overlapping or residual exposure. Do not count them as two independent deals without verification.',
'EX-GEOGRAPHY': 'Confirm what the named country field represents for the record and whether it establishes an operating program relationship in that country, as distinct from credit-risk geography, a framework or a multi-country transaction.',
'DF-STATUS': 'For each project number and source-row locator, confirm whether the commitment remained legally in force on 15 October 2026, was signed/effective, disbursed or utilized, suspended, cancelled, transferred, or closed. Separate original gross commitment from current exposure and disbursement; identify the dated action or publicly citable confirmation.',
'DF-CLASS': 'Confirm the actual instrument and administering unit. Our named-tool mapping is an analyst classification. Explain source instrument codes and whether a Finance row can be assigned to debt or guaranty; keep unresolved and Legacy classifications separate.',
'DF-IDENTITY': 'Project number may repeat across source rows. Provide the durable agreement/subcommitment identifier and explain whether repeated rows are separate tranches, coverage layers, adjustments or duplicate presentation. Do not merge or count them as distinct projects without evidence.',
'DF-FRAMEWORK': 'Confirm whether this row is a parent framework/unallocated commitment, a subcommitment or an underlying project. Identify parent-child links, avoid double counting, and state whether any named-country origination or delivery actually continued on 15 October 2026.',
'DF-INTAKE': 'For an intermediary or loan-portfolio guaranty, distinguish an outstanding agency commitment from an open borrower-origination/enrollment window. Confirm whether new eligible subloans could be enrolled on 15 October 2026, the enrollment end date, partner route and any suspension or capacity restriction that can be disclosed.',
'DF-PMIC': 'Project 9000116385 (DFC-ROW-935): confirm execution/effective dates and October status. The PMIC page has a January 2026 URL but describes signing on 11 July 2024; identify any genuine later amendment or renewal rather than treating page metadata as the agreement date.',
'IN-AGENCY': 'For this country and tool, was the agency accepting new complete applications on 15 October 2026? Distinguish new intake, pre-screening only, renewals/amendments only, waitlist, pause and unavailable. Give the responsible unit, application route, dated conditions and a citable confirmation. This is not a request for transaction approval.',
'IN-EXIM': 'Confirm buyer-sector and tenor-specific cover, applicable country notes, effective dates and exceptions. Separate routine off-cover status from a legal prohibition, and confirm operational processing capacity separately from an online form or a published schedule.',
'IN-DFC': 'Confirm the country/tool-specific legal and policy route, any agreement/sector/income conditions, current review unit and whether the published intake channel was staffed and accepting submissions at the cutoff. Possible-support listings or old agreements alone are not accepted as operational intake evidence.',
'MM-SERVICE': 'Confirm the exact service delivered: Gold Key, International Partner Search, or International Partner Search plus Virtual Introductions. Separate introductions, report delivery, meetings, unrelated mission support and later sales outcomes. Return a public or anonymized service-case reference.',
'MM-DATE': 'Give actual commissioning/start, meeting or report-delivery, and completion dates, or a defensible date range and its precision. Separately confirm any commissioned case being delivered on 15 October 2026 and any delivery completed during 1-15 October 2026; a publication date or later sale is not the service date.',
'MM-INTAKE': 'For each named service and variant, confirm whether new requests were being accepted on 15 October 2026, delivery mode, country-serving office, routing contact, capacity/lead-time restrictions and applicable dated terms. A current menu or office listing alone does not establish acceptance.',
'MM-EVIDENCE': 'Provide a dated service completion note, public case report, anonymized case extract or attributable official confirmation. If no case is found, state the period and records searched and whether the search is complete; distinguish no records found, no disclosure and a verified zero.',
'MM-CR-CASE': 'For Digital Harvest, identify the actual Costa Rica IPS plus Virtual Introductions service dates and report completion date behind the 8 September 2025 story. Identify a separate 2026/October case or continuing commissioned work before treating the historical story as current activity.',
'MM-KE-CASE': 'For Astec, provide Gold Key meeting and completion dates and the official story publication date, if recorded. Identify Kenya as the service market; do not infer service delivery in the ten unnamed additional dealership markets.',
'MM-NR-ROUTE': 'Confirm whether your Suva office is responsible for Gold Key or IPS requests targeting Nauru, or identify the correct office. Diplomatic accreditation and services delivered in Fiji are not evidence of Nauru delivery. State any formal partner-post, regional or virtual arrangement.',
'MM-PH-LEAD': 'The All Good Products lead is not mapped to Gold Key or IPS. Confirm whether either named instrument was used, give service dates and a public/anonymized case reference; otherwise retain it as general Commercial Service assistance.',
}
write_csv(ROOT/'data'/'question_bank.csv',[{'question_code':k,'question':v} for k,v in questions.items()])

contacts=[
('VR-EXIM-01','EXIM','All documented EXIM countries; six priority-country intake checks','info@exim.gov','','Office of Chief Financial Officer (dataset questions), with onward referral to product/underwriting teams','R01;R02;R15','Published general route; specialist assignment unconfirmed. No FOIA addressee selected.'),
('VR-DFC-01','DFC','All documented DFC countries; six priority-country intake checks','data@dfc.gov','info@dfc.gov','Open Data team; onward referral to portfolio and product intake teams','R03;R04','Published data/general routes; individual record owners unconfirmed.'),
('VR-CS-CR','Commerce / Commercial Service','Costa Rica','Clint.Brewer@trade.gov','','Published Costa Rica country contact','R05','Published contact lead; incumbency and delivery not independently tested. Roy.Fernandez@trade.gov is a published fallback, not copied.'),
('VR-CS-GT','Commerce / Commercial Service','Guatemala','Jessica.Gordon@trade.gov','','Published Guatemala country contact','R06','Published contact lead; incumbency and delivery not independently tested.'),
('VR-CS-KE','Commerce / Commercial Service','Kenya','Office.Nairobi@trade.gov','','Nairobi office mailbox','R07','Published shared mailbox; avoids selecting among conflicting named-officer pages.'),
('VR-CS-NR','Commerce / Embassy Suva referral','Nauru (Naoero)','office.fiji@trade.gov','','Suva referral desk; Nauru program responsibility must be confirmed','R10;R11','PROVISIONAL COUNTRY ROUTING: office address is published, but responsibility for Nauru Gold Key/IPS is not established.'),
('VR-CS-PK','Commerce / Commercial Service','Pakistan','office.pakistan@trade.gov','','Pakistan country-team mailbox','R08','Published in a 25 May 2026 Commerce page; delivery not tested.'),
('VR-CS-PH','Commerce / Commercial Service','Philippines','businessphilippines@trade.gov','','Manila country-team mailbox','R09','Published office mailbox; delivery not tested.'),
]
contact_rows=[]
for rid,agency,scope,to,cc,unit,sids,note in contacts:
    contact_rows.append({'request_id':rid,'agency':agency,'scope':scope,'suggested_to':to,'suggested_cc':cc,'requested_routing':unit,'source_ids':sids,'source_urls':' | '.join(sources[s]['url'] for s in sids.split(';')),'routing_qualification':note,'checked':AS_OF,'correspondence_status':'Draft - not sent','sent_date':'','reply_date':''})
write_csv(ROOT/'data'/'routing_register.csv',contact_rows)

# Record-level annexes. Original observations are preserved verbatim in provenance.
finance=[]
for o in obs:
    au=audit[o['observation_id']]; ex=o['program'].startswith('EXIM')
    q=['EX-STATUS','EX-GEOGRAPHY'] if ex else ['DF-STATUS','DF-CLASS','DF-IDENTITY']
    if ex:
        q.append({'recorded_window_spans_snapshot':'EX-SPAN','recorded_window_elapsed':'EX-ELAPSED','effective_missing':'EX-MISSING','expiration_missing':'EX-MISSING','loan_expiration_field_not_defined':'EX-LOAN'}[au['audit']])
        if o['source_record_id'] in ['09782442ST1002','09782442ST1003']: q.append('EX-RENEWAL')
    else:
        if o['framework']=='True' or 'unallocated portion' in o['project_or_borrower'].lower():q.append('DF-FRAMEWORK')
        if o['program']=='DFC02':q.append('DF-INTAKE')
        if o['source_record_id']=='9000116385':q.append('DF-PMIC')
    extra=['S44'] if ex else ['S45']
    if o['source_record_id']=='07099993XXAA01':extra+=['S51']
    if o['source_record_id']=='9000116385':extra+=['S55']
    sids=list(dict.fromkeys([o['source']]+extra))
    finance.append({
    'request_id':'VR-EXIM-01' if ex else 'VR-DFC-01','priority':'1 - priority country' if o['country'] in PRIORITY else '2 - remaining documented country',
    'observation_id':o['observation_id'],'official_source_record_id':o['source_record_id'],'source_export_row_locator':o['source_row'],
    'country_code':o['country'],'country':countries[o['country']],'program_id':o['program'],'program_name':programs[o['program']]['name'],
    'project_or_borrower':o['project_or_borrower'],'source_snapshot':o['evidence_as_of'],'authorization_date':o['record_date'],
    'recorded_effective_date':o['effective_date'],'recorded_expiration_date':o['expiration_date'],'audit_class':au['audit'],
    'audit_qualification':au['qualification'],'raw_instrument_code':o['instrument_code'],'raw_project_type':o['project_type'],'framework_flag':o['framework'],
    'observed_amount_USD':o['approved_or_committed_USD'],'amount_qualification':o['amount_qualification'],'geography_role':o['geography_role'],
    'question_codes':';'.join(q),'record_specific_questions':' '.join(f'[{code}] {questions[code]}' for code in q),
    'source_ids':';'.join(sids),'source_urls':' | '.join(sources[s]['url'] for s in sids),'project_profile_url':o['profile_url'],
    'requested_status_date':AS_OF,'response_state':'Not received','agency_status_at_cutoff':'','status_effective_date':'','executed_effective_utilized_details':'',
    'amendment_or_successor_id':'','evidence_url_or_document_ref':'','responding_unit':'','response_date':'','publication_permission':'','agency_notes':''})
finance.sort(key=lambda x:(x['request_id'],x['priority'],x['country'],x['program_id'],x['observation_id']))
write_csv(ROOT/'data'/'finance_record_requests.csv',finance)

# Union: all 77 documented financial pairs plus 54 priority country/tool rows; 18 overlap.
intake=[]
keys={(x['country'],x['program']) for x in pairs}|set(intake_old)
for co,pr in sorted(keys,key=lambda k:(k[0] not in PRIORITY,countries[k[0]],k[1])):
    old=intake_old.get((co,pr)); ex=pr.startswith('EXIM'); group=[o['observation_id'] for o in obs if (o['country'],o['program'])==(co,pr)]
    sids=json.loads(old['sources']) if old else json.loads(routes[pr]['sources'])
    q=['IN-AGENCY','IN-EXIM' if ex else 'IN-DFC']
    known=old['country_terms'] if old else 'Country-specific intake conditions not refreshed in v0.3; only the national product route was reviewed. This row is a request, not a completed verification.'
    intake.append({'request_id':'VR-EXIM-01' if ex else 'VR-DFC-01','intake_review_id':f'IN-{co}-{pr}',
    'country_code':co,'country':countries[co],'program_id':pr,'program_name':programs[pr]['name'],
    'priority':'1 - priority country' if co in PRIORITY else '2 - remaining documented country','linked_observation_ids':';'.join(group),
    'scope_origin':'Priority 54-row screen' if old else 'Additional intake question for documented financial relationship',
    'prior_evidence_and_limit':known,'question_codes':';'.join(q),'precise_questions':' '.join(f'[{c}] {questions[c]}' for c in q),
    'source_ids':';'.join(sids),'source_urls':' | '.join(sources[s]['url'] for s in sids),'requested_status_date':AS_OF,
    'response_state':'Not received','agency_intake_at_cutoff':'','new_applications_or_renewals_only':'','country_sector_tenor_conditions':'','operating_unit_and_route':'',
    'capacity_or_lead_time_limit':'','status_effective_date':'','evidence_url_or_document_ref':'','response_date':'','publication_permission':'','agency_notes':''})
write_csv(ROOT/'data'/'finance_intake_requests.csv',intake)

match=[]
for r in mm:
    c,p=r['country'],r['program']; mid=f'MM-{c}-{p}'
    qs=['MM-SERVICE','MM-DATE','MM-INTAKE','MM-EVIDENCE']
    if c=='CR' and p=='ITA02':qs.insert(0,'MM-CR-CASE')
    if c=='KE' and p=='ITA01':qs.insert(0,'MM-KE-CASE')
    if c=='NR':qs.insert(0,'MM-NR-ROUTE')
    if c=='PH':qs.append('MM-PH-LEAD')
    contact=next(t for t in contact_rows if t['request_id']==f'VR-CS-{c}')
    sids=list(dict.fromkeys(json.loads(r['sources'])+[('S74' if p=='ITA01' else 'S75')]+contact['source_ids'].split(';')))
    if c=='PH':sids+=['S73']
    match.append({'request_id':f'VR-CS-{c}','match_review_id':mid,'country_code':c,'country':countries[c],'program_id':p,
    'program_name':programs[p]['name'],'existing_case':'Digital Harvest' if (c,p)==('CR','ITA02') else ('Astec' if (c,p)==('KE','ITA01') else ''),
    'agency_case_id':'','id_qualification':'MM identifiers are new internal review keys, NOT official service-case IDs. Agency case IDs were not recovered.',
    'prior_disposition':r['disposition'],'known_evidence':r['summary'],'known_report_date':r['report_date'],'known_service_date':r['event_date'],
    'question_codes':';'.join(qs),'precise_questions':' '.join(f'[{q}] {questions[q]}' for q in qs),'source_ids':';'.join(sids),'source_urls':' | '.join(sources[s]['url'] for s in sids),
    'requested_status_date':AS_OF,'response_state':'Not received','agency_case_reference_or_anonymized_id':'','exact_service_variant':'','actual_service_start':'',
    'actual_service_completion':'','date_precision':'','commissioned_delivery_on_cutoff':'','completed_delivery_1_to_15_october':'','accepting_new_requests_at_cutoff':'',
    'serving_office_and_route':'','evidence_url_or_document_ref':'','records_searched_and_scope':'','response_date':'','publication_permission':'','agency_notes':''})
write_csv(ROOT/'data'/'matchmaking_requests.csv',match)

classification=[]
for o in unc:
    qs=['DF-CLASS','DF-IDENTITY','DF-STATUS']
    if o['framework']=='True' or 'unallocated portion' in o['project_or_borrower'].lower():qs+=['DF-FRAMEWORK']
    classification.append({'request_id':'VR-DFC-01','review_id':'CLASS-'+o['observation_id'],'observation_id':o['observation_id'],
    'official_source_record_id':o['source_record_id'],'source_export_row_locator':o['source_row'],'country_code':o['country'],'country':countries[o['country']],
    'priority':'1 - priority country' if o['country'] in PRIORITY else '3 - supplemental classification','project_or_borrower':o['project_or_borrower'],
    'prior_unallocated_class':o['program'],'raw_instrument_code':o['instrument_code'],'raw_project_type':o['project_type'],'framework_flag':o['framework'],
    'source_snapshot':o['evidence_as_of'],'question_codes':';'.join(qs),'precise_questions':' '.join(f'[{q}] {questions[q]}' for q in qs),
    'source_url':sources[o['source']]['url'],'project_profile_url':o['profile_url'],'counting_rule':'Supplemental only; excluded from 206 mapped observations and 77 mapped country-program relationships.',
    'response_state':'Not received','confirmed_instrument':'','durable_agreement_identifier':'','status_at_cutoff':'','parent_child_relationship':'',
    'evidence_url_or_document_ref':'','response_date':'','publication_permission':'','agency_notes':''})
classification.sort(key=lambda r:(r['priority'],r['country'],r['observation_id']))
write_csv(ROOT/'data'/'dfc_supplemental_classification.csv',classification)

# Per-recipient annexes prevent accidental sharing of the whole working register.
for contact in contact_rows:
    rid=contact['request_id'];d=ROOT/'annexes'/rid;d.mkdir(exist_ok=True)
    if rid.startswith('VR-CS'):
        write_csv(d/'matchmaking_response.csv',[x for x in match if x['request_id']==rid])
    else:
        write_csv(d/'finance_records_response.csv',[x for x in finance if x['request_id']==rid])
        write_csv(d/'intake_response.csv',[x for x in intake if x['request_id']==rid])
        if rid=='VR-DFC-01':write_csv(d/'supplemental_classification_optional.csv',classification)

common_open='I am preparing an informational research paper on U.S. trade-facilitation programs. Please help verify the enclosed public-source records as of 15 October 2026. Please date subsequent changes separately. This is a research inquiry, not a financing application, request for a service engagement, or claim of government affiliation.'
common_close='Please return the relevant CSV with identifiers unchanged, or reply in keyed text. A dated public record or attributable official confirmation is sufficient. Where details cannot be disclosed, please provide a public or anonymized status and state the limitation; confidential client material is not requested. Please indicate whether your response may be cited and attributed. An unknown, declined response, or unanswered item will remain unknown, not inactive.'
signature='Thank you,\n[Sender name]\n[Role / organization, if applicable]\n[Reply email]'
requests=[]
def request(rid,title,subject,blocks,sids,attachments):
    c=next(c for c in contact_rows if c['request_id']==rid)
    body={'request_id':rid,'title':title,'subject':subject,'to':c['suggested_to'],'cc':c['suggested_cc'],
        'routing_note':c['routing_qualification'],'status':'DRAFT - NOT SENT','as_of':AS_OF,
        'attachments':attachments,'blocks':blocks,'source_ids':list(dict.fromkeys(sids)),'signature':signature}
    requests.append(body)

ex_n=sum(r['request_id']=='VR-EXIM-01' for r in intake);df_n=len(intake)-ex_n
request('VR-EXIM-01','EXIM | Continuation and intake',
'Public-record verification at 15 October 2026: EXIM continuation and intake [VR-EXIM-01]',[
('Opening',common_open),
('Scope and routing',f'Please route record questions to the authorization-data custodian in the Office of Chief Financial Officer and the relevant insurance, guarantee and lending teams. Our frozen 30 June extract contains 88 observations across 30 country-tool relationships. The second annex contains {ex_n} country-tool intake questions. The six priority countries are Costa Rica, Guatemala, Kenya, Nauru, Pakistan and the Philippines. There are 14 mapped EXIM observations among four of those countries; no mapped record is not evidence of no activity. [S22, R02]'),
('1. Record identity and operative status','For each official source ID, identify the operative policy, guarantee or loan agreement and its status on the cutoff: authorization only; signed but not effective; in force but unused; utilized; suspended; cancelled; expired with residual exposure; or closed. Provide the controlling effective/action date and any successor or amendment ID. Confirm the meaning of the named-country field. [EX-STATUS, EX-GEOGRAPHY]'),
('2. Dates, renewals and missing fields','Please answer the row-specific questions: 72 recorded date windows span the cutoff, 11 have elapsed, and five have missing or inapplicable fields. A date window is not proof of continuation, and expiry is not proof of zero exposure. In particular, confirm the predecessor/successor relationship for Fly Ace IDs 09782442ST1002 and 09782442ST1003. [EX-SPAN, EX-ELAPSED, EX-MISSING, EX-RENEWAL; S44]'),
('3. Reko Diq: specific clarification','For authorization 07099993XXAA01 / EXIM-07099993XXAA01, did the loan agreement become executed/effective or have a drawdown by 15 October? Was any authorization, availability or agreement revised, suspended or cancelled? Explain raw ExpirationDate 2029-06-30 without assuming it is maturity. Reconcile the status with the sponsor financing review announced on 2 April 2026. No cancellation conclusion has been drawn. [EX-LOAN; S51]'),
('4. New intake, separately from existing cover','For each IN-COUNTRY-PROGRAM row, confirm acceptance of new complete applications versus pre-screening, renewals only, waitlist or pause; state the responsible unit, route, dated conditions and known processing limitations. Please distinguish private/public buyers, tenor and country notes. Prior schedule evidence gives Kenya private short-term cover only and Nauru no routine cover; confirm any changes or applicable exceptions rather than treating these as blanket approval or prohibition. [IN-AGENCY, IN-EXIM; S41, S43]'),
('Response format',common_close+' Please prioritize the 14 priority-country observations and 18 priority intake rows; the remaining annex rows can follow. No formal FOIA request or fee authorization is intended; please advise before treating this inquiry as one.')
],['R01','R02','S22','S44','S41','S43','S51'],['finance_records_response.csv','intake_response.csv'])
request('VR-DFC-01','DFC | Commitment status and origination',
'Public-record verification at 15 October 2026: DFC commitments, IDs and intake [VR-DFC-01]',[
('Opening',common_open),
('Scope and routing',f'Please route the record questions to the portfolio-data custodian and relevant project teams, and the intake questions to the responsible product units. The mapped annex contains 118 source rows representing 47 country-tool relationships, not 118 distinct projects. The intake annex has {df_n} country-tool questions. A separate, optional annex contains 162 unallocated Finance/Legacy rows; these are excluded from the mapped counts. The public database still states 30 June 2026. [S25, R03, R14]'),
('1. Status at the cutoff','For every project number plus source-row locator, confirm whether the commitment remained legally in force on 15 October; distinguish signed/effective, undrawn, utilized, suspended, cancelled, transferred or closed. State action dates and the responsible unit. Separate gross commitment, current exposure and any publicly disclosable utilization; a portfolio label alone does not establish October activity. [DF-STATUS]'),
('2. Instrument mapping and repeated IDs','Confirm the debt, guaranty, insurance, equity, fund or project-development instrument and a durable agreement/subcommitment ID. Source-row locators are snapshot-specific internal keys. Explain repeated project numbers, including 9000024328 (Philippines rows 197/212) and 9000024254 (Pakistan rows 208/210): distinct layers, tranches, amendments or duplicate presentation? Identify parent-framework/subcommitment relationships and geographic scope. [DF-CLASS, DF-IDENTITY, DF-FRAMEWORK]'),
('3. Enrollment and the PMIC date issue','For portfolio guarantees, was the partner permitted and operationally able to enroll new eligible loans on 15 October, or was the record solely outstanding exposure? Give the enrollment end date and routing or capacity restrictions that can be disclosed. For PMIC project 9000116385 / DFC-ROW-935, clarify the execution/effective dates and any later amendment: the January 2026 page URL describes signing on 11 July 2024. [DF-INTAKE, DF-PMIC; S55]'),
('4. New agency applications','For each intake row, distinguish acceptance of new applications, pre-screening only, renewals/amendments only and paused intake. Confirm country/tool conditions, applicable agreements or exceptions, the processing unit, channel and dated operating restrictions. Possible-support lists and agreement documents are not treated as automatic eligibility or intake capacity. Our portal rendering failure is a research-access limitation, not a finding that your portal is down. [IN-AGENCY, IN-DFC; S46, S49]'),
('Response format',common_close+' Please prioritize the 47 mapped observations in Guatemala, Kenya, Pakistan and the Philippines and the 36 intake rows covering all six priority countries. The optional classification annex may be deferred. Please identify the next public data cutoff or update route when a row-level response is unavailable.')
],['R03','R04','R14','S25','S46','S49','S55'],['finance_records_response.csv','intake_response.csv','supplemental_classification_optional.csv (optional; separate from mapped observations)'])

country_specific={
'CR':('The Costa Rica record MM-CR-ITA02 concerns Digital Harvest. Commerce published the IPS plus Virtual Introductions story on 8 September 2025; the actual service dates are not established. MM-CR-ITA01 has no recovered dated Gold Key case. [S52, S30]',
'For Digital Harvest, give commissioning, partner-report, introduction and completion dates or a defensible range. Confirm the IPS plus Virtual Introductions variant and any separately commissioned 2026/October activity. A 2025 story is not being treated as current delivery. For Gold Key, provide a separate attributable case or a scoped non-finding. [MM-CR-CASE]', ['R05','R12','S30','S74','S75']),
'GT':('The review keys are MM-GT-ITA01 (Gold Key) and MM-GT-ITA02 (International Partner Search). The country page points to general services, but no dated, instrument-attributable delivery record was recovered. This is a research gap, not a finding of inactivity. [S71, S72]',
'Please identify one public or anonymized completed case per named service, with actual service dates and the country-serving office. State whether Gold Key and IPS are delivered locally, by a partner post or through another office; a generic service-navigation link is not enough to resolve these records.', ['R06','S71','S74','S75']),
'KE':('MM-KE-ITA01 concerns Astec: the official story explicitly attributes meetings to Gold Key but supplies no recovered absolute service or publication date. MM-KE-ITA02 has no recovered dated IPS case. [S53, S33]',
'For Astec, provide Gold Key meeting/completion dates and the original story date if recorded. Please distinguish the Kenyan service from the later dealership agreement and its ten unnamed additional markets. For IPS, identify a separate dated case rather than reallocating the Gold Key case. [MM-KE-CASE]', ['R07','R13','S33','S74','S75']),
'NR':('The review keys are MM-NR-ITA01 (Gold Key) and MM-NR-ITA02 (International Partner Search). No Nauru-specific service-case ID or delivery date has been recovered. The Suva mailbox is a proposed referral only, based on the published Fiji contact and Suva accreditation; responsibility for these services in Nauru is not established. [R10, R11]',
'Please first confirm whether your office handles Nauru requests for these instruments, or refer this inquiry to the proper team. Identify any formal regional/partner-post or virtual arrangement. Do not substitute a Fiji-only engagement or diplomatic accreditation for Nauru service delivery. A country-specific service may be unavailable, unrequested or simply undocumented; please distinguish these states. [MM-NR-ROUTE]', ['R10','R11','S74','S75']),
'PK':('The review keys are MM-PK-ITA01 (Gold Key) and MM-PK-ITA02 (International Partner Search). The country guide describes the services, but no dated, instrument-specific delivery record was recovered. A published menu is not treated as completed delivery or current acceptance. [S31]',
'Please identify dated public or anonymized cases separately for Gold Key and IPS, distinguishing IPS plus Virtual Introductions where used. State which office (Islamabad, Lahore, Karachi or a serving office elsewhere) commissioned and delivered each case and any material delivery-mode or operational restriction at the cutoff.', ['R08','S31','S74','S75']),
'PH':('The review keys are MM-PH-ITA01 (Gold Key) and MM-PH-ITA02 (International Partner Search). The country guide names both services; dated service delivery remains unresolved. The All Good Products success-story lead was retained as unallocated assistance because the exact instrument and dates were not established. [S29, S73]',
'For All Good Products, confirm whether Gold Key, IPS, a virtual variant or another type of assistance was used, and provide actual dates and a public or anonymized reference. Do not assign the case to either instrument unless supported. A different dated case can answer each review key. [MM-PH-LEAD]', ['R09','S29','S73','S74','S75']),
}
for c in PRIORITY:
    context,specific,sids=country_specific[c]
    request('VR-CS-'+c,f'{countries[c]} | Gold Key and Partner Search',
        f'{countries[c]}: dated Gold Key / Partner Search delivery and intake [VR-CS-{c}]',[
        ('Opening','I am preparing an informational research paper on U.S. trade-facilitation programs. Please verify the two enclosed country-service records as of 15 October 2026, with later changes dated separately. This is a research inquiry, not a client application or request to commission services.'),
        ('Records and existing evidence',context),
        ('1. Resolve the specific record gap',specific),
        ('2. Establish actual delivery, not publicity','For each service, provide the exact variant, actual start and completion/meeting/report dates (or a dated range), and an anonymized or public case reference. Separately identify commissioned work underway on 15 October and any completed delivery during 1-15 October. A public report date or later sale is not the service date. [MM-SERVICE, MM-DATE]'),
        ('3. Confirm intake and evidence limits','Was each service accepting new requests at the cutoff? State the serving office, channel, mode, dated conditions and capacity/lead-time restrictions. Please distinguish a service menu from staff acceptance. A dated official confirmation or anonymized completion extract is sufficient. A non-finding should specify the period and records searched, not imply no activity everywhere. [MM-INTAKE, MM-EVIDENCE]'),
        ('Response format','Please return the two-row annex or reply using the MM review keys. These are internal research IDs, not official case numbers. Supply an agency case ID only when public or anonymized; confidential client information is not requested. Please include the responding unit, date, supporting source and permission to cite. An unknown or non-disclosable answer will remain explicitly qualified.')
        ],sids,['matchmaking_response.csv'])

dump(ROOT/'data'/'request_content.json',requests)
for r in requests:
    text=[r['status'],r['title'],f"Request ID: {r['request_id']} | Status date requested: {AS_OF}",f"Suggested To: {r['to']}"]
    if r['cc']:text.append('Suggested Cc: '+r['cc'])
    text += ['Routing qualification: '+r['routing_note'],'Subject: '+r['subject'],
        'Attach from annexes/'+r['request_id']+'/: '+', '.join(r['attachments']),'','Dear '+('EXIM team,' if r['request_id']=='VR-EXIM-01' else 'DFC team,' if r['request_id']=='VR-DFC-01' else 'Commercial Service team,'),'']
    for label,body in r['blocks']:text += [label,body,'']
    text += [r['signature'],'','Public sources and routing references']
    for sid in r['source_ids']:text.append(f"[{sid}] {sources[sid]['title']}\n{sources[sid]['url']}")
    text += ['','Preparation note: no message sent, no email-account draft created, and no recipient or application portal contacted. Replace bracketed sender details only before using this draft.']
    (ROOT/'drafts'/f"{r['request_id']}.txt").write_text('\n'.join(text)+'\n',encoding='utf-8')

# Stable counts and map-to-reply protocol. No prior atlas status is upgraded.
metrics={
 'requests':len(requests),'mapped_finance_observations':len(finance),'mapped_finance_pairs':len({(r['country_code'],r['program_id']) for r in finance}),
 'exim_observations':sum(r['request_id']=='VR-EXIM-01' for r in finance),'dfc_observations':sum(r['request_id']=='VR-DFC-01' for r in finance),
 'priority_finance_observations':sum(r['country_code'] in PRIORITY for r in finance),'finance_intake_questions':len(intake),
 'exim_intake_questions':ex_n,'dfc_intake_questions':df_n,'priority_intake_questions':54,'priority_intake_overlap_with_mapped_pairs':18,
 'matchmaking_questions':len(match),'dfc_supplemental_classification_rows':len(classification),'messages_sent':0,'mail_account_drafts_created':0,
 'agency_replies_received':0,'new_october_status_confirmations':0,'source_snapshot':'2026-06-30','status_date_requested':AS_OF,
 'financial_audit_counts':dict(collections.Counter(r['audit_class'] for r in finance))}
dump(ROOT/'data'/'metrics.json',metrics)

checks=[]
def check(name,condition):
    checks.append({'check':name,'passed':bool(condition)})
    if not condition: raise AssertionError(name)
check('Exactly eight drafts',len(requests)==8)
check('All 206 mapped observations preserved exactly once',len(finance)==206 and {r['observation_id'] for r in finance}=={r['observation_id'] for r in obs})
check('All official source IDs preserved verbatim',all(next(o['source_record_id'] for o in obs if o['observation_id']==r['observation_id'])==r['official_source_record_id'] for r in finance))
check('88 EXIM and 118 DFC rows',metrics['exim_observations']==88 and metrics['dfc_observations']==118)
check('77 unique mapped finance pairs',metrics['mapped_finance_pairs']==77)
check('61 priority finance observations',metrics['priority_finance_observations']==61)
check('113 union intake rows without duplicated pair keys',len(intake)==113 and len({(r['country_code'],r['program_id']) for r in intake})==113)
check('Every mapped pair has a separate intake question',{(r['country_code'],r['program_id']) for r in finance}<={(r['country_code'],r['program_id']) for r in intake})
check('All 54 old priority intake pairs included',set(intake_old)<={(r['country_code'],r['program_id']) for r in intake})
check('All 12 priority matchmaking relationships included',len(match)==12 and {(r['country_code'],r['program_id']) for r in match}=={(c,p) for c in PRIORITY for p in ['ITA01','ITA02']})
check('No invented matchmaking agency case IDs',all(not r['agency_case_id'] for r in match))
check('162 supplemental rows separate from mapped observations',len(classification)==162 and not ({r['observation_id'] for r in classification}&{r['observation_id'] for r in finance}))
check('No responses prefilled',all(r['response_state']=='Not received' for a in [finance,intake,match,classification] for r in a))
check('No contact marked sent',all(r['correspondence_status']=='Draft - not sent' and not r['sent_date'] for r in contact_rows))
check('Every linked question code resolves',all(c in questions for a in [finance,intake,match,classification] for r in a for c in r['question_codes'].split(';')))
check('Every draft source resolves to an HTTPS URL',all(s in sources and sources[s]['url'].startswith('https://') for r in requests for s in r['source_ids']))
check('Every row has a source URL',all(r.get('source_urls',r.get('source_url','')) for a in [finance,intake,match,classification] for r in a))
check('Nauru routing explicitly provisional','PROVISIONAL' in next(r for r in contact_rows if r['request_id']=='VR-CS-NR')['routing_qualification'])
check('Reko Diq ID retains leading zero','07099993XXAA01' in [r['official_source_record_id'] for r in finance])
check('Both Fly Ace policy rows preserved',{'09782442ST1002','09782442ST1003'}<={r['official_source_record_id'] for r in finance})
check('DFC duplicated project IDs retain separate row keys',len([r for r in finance if r['official_source_record_id']=='9000024328'])==2)
check('Source export row locators retained, not treated as durable IDs',all(r['source_export_row_locator']==next(o['source_row'] for o in obs if o['observation_id']==r['observation_id']) for r in finance))
for r in requests:
    for f in r['attachments']:
        f=f.split(' (')[0]
        check('Attachment exists '+r['request_id']+'/'+f,(ROOT/'annexes'/r['request_id']/f).exists())
dump(ROOT/'validation'/'data_checks.json',{'passed':sum(x['passed'] for x in checks),'total':len(checks),'checks':checks})
manifest_path = ROOT/'provenance'/'provenance_manifest.json'
prior_manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
dump(ROOT/'provenance'/'provenance_manifest.json',{'basis':'Atlas v0.3 frozen data; no raw-finance refresh and no atlas edits in this pass',
 'original_zip':'Trade_Over_Aid_Map_Matrix_Prototype_v0_3.zip',
 'original_zip_sha256':hashlib.sha256(Path('/mnt/data/Trade_Over_Aid_Map_Matrix_Prototype_v0_3.zip').read_bytes()).hexdigest() if Path('/mnt/data/Trade_Over_Aid_Map_Matrix_Prototype_v0_3.zip').exists() else prior_manifest.get('original_zip_sha256'),
 'files':[{'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((ROOT/'provenance').glob('*.csv'))]})
print(json.dumps(metrics,indent=2))
print('Data checks:',len(checks),'passed')
