"""Build the response tracker with artifact_tool. Run in its Python runtime.
No source records are overwritten; replies are blank and correspondence is unsent.
"""
from pathlib import Path
import csv,json,math
from datetime import datetime
from artifact_tool import Workbook,SpreadsheetFile
ROOT=Path(__file__).resolve().parents[1]
def load(name):
    with (ROOT/'data'/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
def col(n):
    s=''
    while n:
        n,k=divmod(n-1,26);s=chr(65+k)+s
    return s

def shorten(s,n=155):
    return s if len(s)<=n else s[:n-3]+'...'
def date(s):
    return datetime.strptime(s,'%Y-%m-%d') if s else None

def primary_url(s):return s.split(' | ')[0] if s else ''

# Use the existing workbook when executed in one continuous notebook state.
try: wb
except NameError: wb=Workbook.create()
NAVY='#173D53'; BLUE='#126782'; PALE='#EEF4F7'; YELLOW='#FFF5D6'; INK='#203845'
sheets={}

def make_table(name,title,note,headers,values,widths,editable_from=None,status_col=None,date_cols=(),text_cols=(),height=58):
    sh=wb.worksheets.add(name);sheets[name]=sh
    n=len(headers);end=4+len(values)
    sh.get_range(f'A1:{col(n)}1').merge();sh.get_range('A1').values=[[title]]
    sh.get_range(f'A1:{col(n)}1').format={'fill':NAVY,'font':{'bold':True,'color':'#FFFFFF'},'row_height':30}
    sh.get_range(f'A2:{col(n)}2').merge();sh.get_range('A2').values=[[note]]
    sh.get_range(f'A2:{col(n)}2').format={'font':{'color':INK},'row_height':30,'wrap_text':True}
    sh.get_range(f'A4:{col(n)}{end}').values=[headers]+values
    sh.get_range(f'A4:{col(n)}4').format={'fill':BLUE,'font':{'bold':True,'color':'#FFFFFF'},'wrap_text':True,'row_height':45,'vertical_alignment':'center'}
    if values:
        sh.get_range(f'A5:{col(n)}{end}').format={'fill':'#FFFFFF','row_height':height,'wrap_text':True,'vertical_alignment':'top'}
        if editable_from:
            sh.get_range(f'{col(editable_from)}5:{col(n)}{end}').format.fill=YELLOW
    for i,width in enumerate(widths,1):sh.get_range(f'{col(i)}1:{col(i)}{end}').format.column_width=width
    for i in text_cols:sh.get_range(f'{col(i)}5:{col(i)}{end}').set_number_format('@')
    for i in date_cols:sh.get_range(f'{col(i)}5:{col(i)}{end}').set_number_format('yyyy-mm-dd')
    if status_col:
        sh.get_range(f'{col(status_col)}5:{col(status_col)}{end}').data_validation={'rule':{'type':'list','values':['Not received','Partial','Complete','Declined']}}
        sh.get_range(f'{col(status_col)}5:{col(status_col)}{end}').conditional_formats.add_custom(f'={col(status_col)}5="Complete"',{'fill':'#DDEFE4'})
    sh.freeze_panes.freeze_rows(4)
    sh.tables.add(f'A4:{col(n)}{end}',True,'T'+name.replace(' ','').replace('-',''))
    return sh,end

# Dashboard / usage guide.
dash=wb.worksheets.add('Dashboard');sheets['Dashboard']=dash
dash.get_range('A1:H2').merge();dash.get_range('A1').values=[['AGENCY VERIFICATION | RESPONSE TRACKER']]
dash.get_range('A1:H2').format={'fill':NAVY,'font':{'bold':True,'color':'#FFFFFF'},'row_height':26,'vertical_alignment':'center'}
dash.get_range('A3:H3').merge();dash.get_range('A3').values=[['Requested status: 15 October 2026 | Source-finance snapshot: 30 June 2026 | DRAFTS ONLY']]
dash.get_range('A3:H3').format={'fill':PALE,'row_height':30}
dash.get_range('A5:D5').merge();dash.get_range('A5').values=[['Verification coverage']]
dash.get_range('E5:H5').merge();dash.get_range('E5').values=[['Correspondence and replies']]
for rg in ['A5:D5','E5:H5']:dash.get_range(rg).format={'fill':BLUE,'font':{'bold':True,'color':'#FFFFFF'},'row_height':24}
for i in range(1,9):dash.get_range(f'{col(i)}1:{col(i)}32').format.column_width=14
for row,label in [(6,'EXIM observations'),(7,'DFC observations'),(8,'Intake questions'),(9,'Matchmaking reviews'),(10,'Optional DFC classifications')]:
    dash.get_range(f'A{row}:C{row}').merge();dash.get_range(f'A{row}').values=[[label]]
for row,label in [(6,'Prepared drafts'),(7,'Marked sent externally'),(8,'Finance replies logged'),(9,'Intake replies logged'),(10,'Matchmaking replies logged')]:
    dash.get_range(f'E{row}:G{row}').merge();dash.get_range(f'E{row}').values=[[label]]
dash.get_range('A6:H10').format.row_height=28
dash.get_range('D6:D10').format={'fill':PALE,'font':{'bold':True},'horizontal_alignment':'center'}
dash.get_range('H6:H10').format={'fill':PALE,'font':{'bold':True},'horizontal_alignment':'center'}
notes=[
(12,'What is ready','Eight source-linked drafts plus recipient-specific CSV annexes. No email has been sent or saved in a mail account.'),
(14,'How to use','Preserve all identifiers. Enter replies in pale-yellow fields. Response state tracks receipt/completeness, NOT whether activity is confirmed.'),
(16,'Separate concepts','Existing instrument continuation, new application intake, actual service delivery and publication permission must be recorded separately.'),
(18,'Dates and precision','Use actual YYYY-MM-DD dates when known. For ranges or approximate dates, use notes/date precision; do not invent a day.'),
(20,'Citations','Source columns contain original URLs. Return a dated evidence URL or document reference and the responding unit. Original source files are frozen in provenance/.'),
(22,'Scope','113 intake questions = 77 documented country/tool pairs plus 54 priority combinations, less 18 overlaps. Intake-only rows are not new financing observations.'),
(24,'Identifier discipline','EXIM/DFC agency IDs are preserved as text. MM-* and IN-* are internal review keys. DFC-ROW-* is a snapshot locator, not a durable agency ID.'),
(26,'Priority','Costa Rica, Guatemala, Kenya, Nauru, Pakistan and the Philippines. Nauru-to-Suva routing is provisional; confirm the responsible program office.'),
(28,'No negative inference','No response, no disclosure and incomplete searches remain unknown. Do not treat a blank reply or a closed award as absence of a whole program.'),
(30,'Sending boundary','Use only the matching annexes/VR-... folder for a recipient. This all-agency master is for review; no automatic mail operation is included.'),
]
for row,label,text in notes:
    dash.get_range(f'A{row}:B{row+1}').merge();dash.get_range(f'A{row}').values=[[label]]
    dash.get_range(f'C{row}:H{row+1}').merge();dash.get_range(f'C{row}').values=[[text]]
    dash.get_range(f'A{row}:B{row+1}').format={'fill':PALE,'font':{'bold':True},'wrap_text':True,'vertical_alignment':'center'}
    dash.get_range(f'C{row}:H{row+1}').format={'wrap_text':True,'vertical_alignment':'center'}
    dash.get_range(f'A{row}:H{row+1}').format.row_height=23

contacts=load('routing_register.csv')
headers=['Request ID','Agency / scope','Suggested To','Suggested Cc','Routing qualification','Routing source URLs','Status','Sent date','Reply date','Reviewer notes']
vals=[[r['request_id'],r['agency']+' | '+r['scope'],r['suggested_to'],r['suggested_cc'],r['routing_qualification'],r['source_urls'],r['correspondence_status'],None,None,''] for r in contacts]
sh,req_end=make_table('Requests','DRAFT REQUEST REGISTER','Published routes are suggestions, not tested mailboxes. No send action occurs when this workbook is edited.',headers,vals,[19,39,36,26,58,67,24,16,16,40],7,None,(8,9),(1,),85)
sh.get_range(f'G5:G{req_end}').data_validation={'rule':{'type':'list','values':['Draft - not sent','Sent externally','Reply received','Closed after reconciliation']}}

finance=load('finance_record_requests.csv')
fh=['Priority','Observation ID','Official source ID','Country','Tool ID','Counterparty','Source snapshot','Recorded effective','Recorded expiration','Prior date audit','Question codes','Source URL','Response state','Agency status at cutoff','Status effective date','Executed / effective / utilized','Successor / amendment ID','Reply evidence URL or reference','Responding unit','Reply date','Permission to cite','Agency notes','Export row locator','Instrument code','Project profile URL']
fwidth=[23,25,25,23,14,43,16,17,17,32,43,68,18,32,18,43,30,65,35,16,23,50,19,21,60]
ends={}
for agency,name in [('VR-EXIM-01','EXIM records'),('VR-DFC-01','DFC records')]:
    group=[r for r in finance if r['request_id']==agency]
    vals=[]
    for r in group:
        vals.append([r['priority'],r['observation_id'],r['official_source_record_id'],r['country'],r['program_id'],r['project_or_borrower'].split(';')[0],date(r['source_snapshot']),date(r['recorded_effective_date']),date(r['recorded_expiration_date']),r['audit_class'],r['question_codes'],primary_url(r['source_urls']),'Not received','',None,'','','','',None,'','',r['source_export_row_locator'],r['raw_instrument_code'],r['project_profile_url']])
    sh,end=make_table(name,name.upper()+' | CUTOFF 15 OCTOBER 2026','Row-specific question wording is in Questions and the recipient CSV. Original amounts/complete descriptions stay in provenance and CSV; no amounts are aggregated.',fh,vals,fwidth,13,13,(7,8,9,15,20),(2,3,5,17,23,24),62)
    sh.get_range(f'W5:Y{end}').format.fill='#FFFFFF'  # Source fields, not response inputs.
    ends[name]=end

intake=load('finance_intake_requests.csv')
ih=['Priority','Internal review ID','Country','Tool ID','Prior scope','Prior conditions (short; full CSV)','Question codes','Source URL','Response state','Intake at cutoff','New applications / renewals only','Confirmed country / sector / tenor terms','Operating unit and route','Capacity / lead-time limitation','Status effective date','Evidence URL or reference','Reply date','Permission to cite','Agency notes']
ivals=[[r['priority'],r['intake_review_id'],r['country'],r['program_id'],r['scope_origin'],shorten(r['prior_evidence_and_limit']),r['question_codes'],primary_url(r['source_urls']),'Not received','','','','','',None,'',None,'',''] for r in intake]
sh,end=make_table('Intake','INTAKE | SEPARATE FROM EXISTING FINANCING','113 questions, not 113 verified open programs. Program IDs resolve in CSV and Questions. Source descriptions are prior evidence, not present agency answers.',ih,ivals,[23,24,23,14,35,49,25,67,18,35,34,43,44,40,19,65,16,23,45],9,9,(15,17),(2,4),74);ends['Intake']=end

matches=load('matchmaking_requests.csv')
mh=['Internal review ID','Country','Tool ID','Known case / lead','Prior disposition','Known report date','Question codes','Source URL','Response state','Agency case reference','Exact service variant','Service start','Service completion','Date precision / range','Commissioned delivery on cutoff','Completed delivery 1-15 October','New requests accepted at cutoff','Serving office / route','Evidence URL or reference','Search scope / completeness','Reply date','Permission to cite','Agency notes']
mvals=[[r['match_review_id'],r['country'],r['program_id'],r['existing_case'],r['prior_disposition'],date(r['known_report_date']),r['question_codes'],primary_url(r['source_urls']),'Not received','','',None,None,'','','','','','','',None,'',''] for r in matches]
sh,end=make_table('Matchmaking','MATCHMAKING | GOLD KEY AND INTERNATIONAL PARTNER SEARCH','MM-* keys are internal reviews, not official service-case IDs. Actual delivery dates, publication dates, ongoing work and current intake are separate.',mh,mvals,[24,24,14,25,37,17,52,72,18,32,35,18,18,30,36,36,36,40,67,46,16,23,42],9,9,(6,12,13,21),(1,3,10),80);ends['Matchmaking']=end

supp=load('dfc_supplemental_classification.csv')
suph=['Priority','Internal review ID','Observation ID','Official project ID','Export row locator','Country','Counterparty','Prior unallocated class','Instrument code','Source snapshot','Question codes','Source URL','Response state','Confirmed instrument','Durable agreement ID','Status at cutoff','Parent / child relationship','Evidence URL or reference','Reply date','Permission to cite','Agency notes']
supv=[[r['priority'],r['review_id'],r['observation_id'],r['official_source_record_id'],r['source_export_row_locator'],r['country'],r['project_or_borrower'].split(';')[0],r['prior_unallocated_class'],r['raw_instrument_code'],date(r['source_snapshot']),r['question_codes'],r['source_url'],'Not received','','','','','',None,'',''] for r in supp]
sh,end=make_table('DFC supplemental','DFC | OPTIONAL CLASSIFICATION ANNEX','162 unallocated Finance/Legacy rows. These are NOT included in the 206 mapped observations or 77 mapped country/tool pairs.',suph,supv,[27,27,23,26,19,24,49,39,22,17,52,69,18,34,30,34,43,69,16,23,45],13,13,(10,19),(2,3,4,5,15),68);ends['DFC supplemental']=end

q=load('question_bank.csv')
sh,end=make_table('Questions','QUESTION BANK | PRECISE WORDING','Codes map to full record-specific questions in the CSV annexes. Answer only the requested records and dimensions; keep unsupported fields unknown.',['Question code','Question'],[[r['question_code'],r['question']] for r in q],[25,115],height=80)
for i,r in enumerate(q,5):sh.get_range(f'A{i}:B{i}').format.row_height=max(65,math.ceil(len(r['question'])/100)*14+12)

sources=load('source_register.csv')
sh,end=make_table('Sources','SOURCE REGISTER | INHERITED AND NEW ROUTING EVIDENCE','S* = preserved atlas evidence. R* = this pass routing/case checks. A source check is not agency confirmation; raw financial endpoints were not refreshed.',['Source ID','Title','URL','Source kind','Access mode','Reviewed / retrieved','Qualification'],[[r['id'],r['title'],r['url'],r['kind'],r['access'],date(r['retrieved']) if r['retrieved'] else None,r['note']] for r in sources],[15,48,76,27,48,19,100],date_cols=(6,),text_cols=(1,),height=80)
for i,r in enumerate(sources,5):sh.get_range(f'A{i}:G{i}').format.row_height=max(65,math.ceil(len(r['note'])/95)*14+10,math.ceil(len(r['url'])/74)*14+10)

# All derived metrics are workbook formulas, not frozen painted numbers.
for row,name,idcol in [(6,'EXIM records','B'),(7,'DFC records','B'),(8,'Intake','B'),(9,'Matchmaking','A'),(10,'DFC supplemental','B')]:
    dash.get_range(f'D{row}').formulas=[[f"=COUNTA('{name}'!{idcol}5:{idcol}{ends[name]})"]]
dash.get_range('H6').formulas=[[f"=COUNTA(Requests!A5:A{req_end})"]]
dash.get_range('H7').formulas=[[f'=COUNTIF(Requests!G5:G{req_end},"Sent externally")+COUNTIF(Requests!G5:G{req_end},"Reply received")+COUNTIF(Requests!G5:G{req_end},"Closed after reconciliation")']]
dash.get_range('H8').formulas=[[f'=COUNTIF(\'EXIM records\'!M5:M{ends["EXIM records"]},"Partial")+COUNTIF(\'EXIM records\'!M5:M{ends["EXIM records"]},"Complete")+COUNTIF(\'EXIM records\'!M5:M{ends["EXIM records"]},"Declined")+COUNTIF(\'DFC records\'!M5:M{ends["DFC records"]},"Partial")+COUNTIF(\'DFC records\'!M5:M{ends["DFC records"]},"Complete")+COUNTIF(\'DFC records\'!M5:M{ends["DFC records"]},"Declined")']]
for cell,name in [('H9','Intake'),('H10','Matchmaking')]:
    dash.get_range(cell).formulas=[[f'=COUNTIF(\'{name}\'!I5:I{ends[name]},"Partial")+COUNTIF(\'{name}\'!I5:I{ends[name]},"Complete")+COUNTIF(\'{name}\'!I5:I{ends[name]},"Declined")']]

def save_verify():
    (ROOT/'validation').mkdir(exist_ok=True)
    result=wb.inspect({'kind':'table','range':'Dashboard!A5:H10','include':'values,formulas','table_max_rows':6,'table_max_cols':8})
    (ROOT/'validation'/'workbook_dashboard_inspect.ndjson').write_text(result.ndjson)
    print(result.ndjson)
    errors=wb.inspect({'kind':'match','search_term':'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A','options':{'use_regex':True,'max_results':20},'summary':'Formula-error scan'})
    (ROOT/'validation'/'workbook_error_scan.ndjson').write_text(errors.ndjson);print(errors.ndjson)
    SpreadsheetFile.export_xlsx(wb).save(str(ROOT/'Agency_Verification_Response_Tracker_v0_4.xlsx'))
    wb.render({'sheet_name':'Dashboard','range':'A1:H31','scale':1.4}).save('/mnt/data/_workbook_dashboard.png')
    wb.render({'sheet_name':'EXIM records','range':'A4:F9','scale':1.2}).save('/mnt/data/_workbook_records.png')
    print('Workbook exported and previews rendered')
if __name__ == '__main__':
    save_verify()
