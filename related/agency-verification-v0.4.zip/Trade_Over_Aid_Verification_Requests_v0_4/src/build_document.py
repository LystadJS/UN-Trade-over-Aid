"""Create the editable request packet. Render separately before release."""
from pathlib import Path
import json,csv,re
from docx import Document
from docx.shared import Inches,Pt,RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT,WD_CELL_VERTICAL_ALIGNMENT
from docx.opc.constants import RELATIONSHIP_TYPE as RT
ROOT=Path(__file__).resolve().parents[1]
reqs=json.loads((ROOT/'data/request_content.json').read_text())
metrics=json.loads((ROOT/'data/metrics.json').read_text())
def read(n):
 with (ROOT/'data'/n).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))
src={s['id']:s for s in read('source_register.csv')}
contacts=read('routing_register.csv')
doc=Document(); sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=Inches(.60);sec.bottom_margin=Inches(.60);sec.left_margin=Inches(.72);sec.right_margin=Inches(.72)
sec.header_distance=Inches(.26);sec.footer_distance=Inches(.26)
styles=doc.styles
for name in ['Normal','Body Text']:
 styles[name].font.name='Calibri';styles[name].font.size=Pt(10)
 styles[name].paragraph_format.space_after=Pt(5)
 styles[name].paragraph_format.line_spacing=1.06
for name,size,color in [('Title',27,'14364E'),('Heading 1',19,'14364E'),('Heading 2',12,'14364E'),('Heading 3',10.5,'14364E')]:
 styles[name].font.name='Calibri';styles[name].font.size=Pt(size);styles[name].font.color.rgb=RGBColor.from_string(color)
 styles[name].paragraph_format.space_before=Pt(8);styles[name].paragraph_format.space_after=Pt(5)
 styles[name].paragraph_format.keep_with_next=True
styles['Caption'].font.size=Pt(8.5)
header=sec.header.paragraphs[0]; header.text='TRADE OVER AID  /  RESEARCH VERIFICATION';header.style=styles['Caption']
header.runs[0].font.color.rgb=RGBColor.from_string('587080')
footer=sec.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
footer.add_run('DRAFT • NOT SENT   |   15 OCT 2026   |   ').font.size=Pt(8)
fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)
doc.core_properties.title='Agency verification requests | Trade Over Aid | v0.4'
doc.core_properties.subject='Unsent requests for October 2026 financing continuation, intake and matchmaking evidence'
doc.core_properties.author='Trade Over Aid research project'
doc.core_properties.keywords='Draft, not sent, EXIM, DFC, Commercial Service, verification'

def p(txt='',style=None):return doc.add_paragraph(txt,style)
def link(par,text,url):
 h=OxmlElement('w:hyperlink');h.set(qn('r:id'),par.part.relate_to(url,RT.HYPERLINK,is_external=True))
 r=OxmlElement('w:r');rp=OxmlElement('w:rPr');c=OxmlElement('w:color');c.set(qn('w:val'),'17647E');rp.append(c)
 u=OxmlElement('w:u');u.set(qn('w:val'),'single');rp.append(u);r.append(rp)
 t=OxmlElement('w:t');t.text=text;r.append(t);h.append(r);par._p.append(h)

def tagtext(par,label,text):
 par.add_run(label).bold=True;par.add_run(text)

def table(headers,rows,widths):
 t=doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 for i,(h,w) in enumerate(zip(headers,widths)):
  cell=t.rows[0].cells[i];cell.text=h;cell.width=Inches(w)
  tcpr=cell._tc.get_or_add_tcPr();sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'16394F');tcpr.append(sh)
  for r in cell.paragraphs[0].runs:r.bold=True;r.font.color.rgb=RGBColor(255,255,255);r.font.size=Pt(9)
 trpr=t.rows[0]._tr.get_or_add_trPr();rep=OxmlElement('w:tblHeader');rep.set(qn('w:val'),'true');trpr.append(rep)
 for ri,row in enumerate(rows):
  cells=t.add_row().cells
  for ci,(txt,w) in enumerate(zip(row,widths)):
   cell=cells[ci];cell.width=Inches(w);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER;cell.text=str(txt)
   for par in cell.paragraphs:
    par.paragraph_format.space_before=Pt(3);par.paragraph_format.space_after=Pt(3)
    for run in par.runs:run.font.size=Pt(9)
   if ri%2==0:
    sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'F0F5F7');cell._tc.get_or_add_tcPr().append(sh)
  pr=t.rows[-1]._tr.get_or_add_trPr();ns=OxmlElement('w:cantSplit');pr.append(ns)
 return t

p('Agency verification\nrequests','Title')
p('October financing continuation, application intake and named-service delivery','Subtitle')
p('VERSION 0.4  •  CORRESPONDENCE ADDENDUM TO ATLAS v0.3','Caption')
p('Eight prepared requests. No messages sent. No mail-account drafts created. This packet asks agencies to resolve evidence gaps; it does not resolve those gaps itself.')
table(['Workstream','Prepared coverage'],[
('EXIM continuation','88 source observations across 30 country–tool relationships'),
('DFC continuation','118 source observations across 47 country–tool relationships'),
('Intake, separately','113 country–tool questions: 77 documented pairs plus the 54 priority combinations, with 18 overlaps'),
('Gold Key / Partner Search','12 country–service reviews across six priority countries'),
('DFC supplemental classification','162 Finance/Legacy rows, kept outside mapped-finance counts'),
], [1.9,5.1])
p('Routing map','Heading 2')
table(['Draft','Published suggested route'],[(r['request_id'],r['suggested_to']+(' (provisional Nauru referral)' if r['request_id']=='VR-CS-NR' else '')) for r in contacts],[1.5,5.5])
p('Routing addresses were checked against the linked official sources on 15 October 2026. Mailbox delivery, staff incumbency and responsibility for individual records were not tested. Nauru program responsibility is explicitly unresolved. Each draft includes its own routing source.','Caption')
p('Use the draft text and only the matching recipient-specific annex folder. The combined workbook is a reviewer master, not a suggested attachment to every recipient. Sender name, affiliation and reply address remain placeholders; no government title or authority is assumed.','Caption')

doc.add_page_break()
p('Evidence and reply protocol','Heading 1')
p('Keep four questions separate','Heading 2')
table(['Question','Minimum useful response'],[
('Record continuation','Correct official identifier; status at 15 October 2026; action/effective date; controlling document or attributable official confirmation.'),
('New application intake','Country, named tool, applications versus renewals, operating unit/channel, date and any published limitations. A live form is not acceptance.'),
('Service delivery','Exact Gold Key / IPS variant, country served, case reference, actual service dates or stated precision, and dated completion or ongoing-work evidence.'),
('Publication permission','Responding unit, response date, citable source or document reference, and permission to quote or attribute. Do not request confidential case files.'),
],[1.8,5.2])
p('Identifiers and dates','Heading 2')
p('EXIM source IDs and DFC project numbers are copied verbatim, including leading zeros. EXIM-* and DFC-ROW-* are inherited research observation keys. DFC source-row locators belong to the frozen export, not a permanent agency numbering system. Repeated project numbers remain separate pending agency clarification.')
p('MM-COUNTRY-ITA01/ITA02 and IN-COUNTRY-PROGRAM are new internal review IDs. They are not official case numbers or evidence that a transaction exists. No agency service-case ID has been invented.')
p('The requested state is 15 October 2026. Record later changes separately. The underlying financial snapshot is 30 June 2026. An announcement, report date, agreement signature, effectiveness, disbursement and service delivery are different events.')
p('How replies change the research register','Heading 2')
for label,txt in [
('Sufficient confirmation. ','Update only the matching row and dimension, retaining the previous value and attaching the response source, effective date and scope.'),
('Partial confirmation. ','Record the supported fact and leave unanswered dimensions unknown. Confirmation of a national program cannot be spread to every country or product.'),
('Conflicting evidence. ','Preserve both sources; identify which later dated action supersedes which earlier claim. Escalate unresolved conflicts rather than choosing the more convenient version.'),
('No reply, no records or no disclosure. ','Do not recode to inactive. A true zero requires an explicit searched period and sufficiently complete record scope. A cancelled instrument does not terminate its whole program.'),
]:tagtext(p(),label,txt)
p('Scope and priority','Heading 2')
p('Priority: Costa Rica, Guatemala, Kenya, Nauru, Pakistan and the Philippines. The finance annexes place their 61 mapped observations first. The 54 priority intake combinations include countries/tools without a mapped observation; those are intake inquiries, not invented financing records. The earlier participation evidence remains qualified; this is not a roster certification.')
p('Only correspondence artifacts are changed in this addendum. The atlas, raw financial observations and October-status classifications remain unchanged. All response fields are unfilled or “Not received.”')

for r in reqs:
 doc.add_page_break()
 p(r['title'],'Heading 1')
 meta=p();tagtext(meta,'Request: ',r['request_id']+'  |  DRAFT - NOT SENT')
 meta=p();tagtext(meta,'Suggested To: ',r['to']+('  |  Cc: '+r['cc'] if r['cc'] else ''))
 tagtext(p(),'Subject: ',r['subject'])
 meta=p(style='Caption');tagtext(meta,'Annex: ','annexes/'+r['request_id']+'/  |  '+', '.join(r['attachments']))
 p('Routing: '+r['routing_note'],'Caption')
 p('Dear '+('EXIM team,' if r['request_id']=='VR-EXIM-01' else 'DFC team,' if r['request_id']=='VR-DFC-01' else 'Commercial Service team,'))
 for label,body in r['blocks']:
  par=p();par.paragraph_format.keep_together=True
  if label != 'Opening':par.add_run(label+'. ').bold=True
  par.add_run(body)
 p('Thank you,\n[Sender name] | [Role / organization, if applicable] | [Reply email]')
 par=p(style='Caption');par.add_run('Source links: ').bold=True
 for i,sid in enumerate(r['source_ids']):
  s=src[sid]
  if i:par.add_run('  |  ')
  link(par,f"[{sid}] {s['title']}",s['url'])
 par.paragraph_format.keep_together=True

out=ROOT/'Agency_Verification_Requests_v0_4.docx';doc.save(out)
print(out)
print('Request word counts:',[(r['request_id'],sum(len(t.split()) for _,t in r['blocks'])) for r in reqs])
