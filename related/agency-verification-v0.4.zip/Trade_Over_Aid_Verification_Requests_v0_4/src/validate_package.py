"""Validate document/workbook structures and the frozen request package.
Uses standard-library OOXML inspection, not a spreadsheet creation/editing engine.
Run after all three build scripts. Internal rendered-PDF checks are optional.
"""
from pathlib import Path
import csv, hashlib, json, re, zipfile
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
N={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main','r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships','w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
checks=[]
def check(name,condition):
    checks.append({'check':name,'passed':bool(condition)})
    if not condition: raise AssertionError(name)
def rows(name):
    with (ROOT/'data'/name).open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
finance=rows('finance_record_requests.csv'); intake=rows('finance_intake_requests.csv'); mm=rows('matchmaking_requests.csv'); routes=rows('routing_register.csv')
src={r['id']:r for r in rows('source_register.csv')}
reqs=json.loads((ROOT/'data'/'request_content.json').read_text())
if isinstance(reqs,dict): reqs=reqs['requests']
with zipfile.ZipFile(ROOT/'Agency_Verification_Requests_v0_4.docx') as z:
    check('DOCX archive integrity',z.testzip() is None)
    root=ET.fromstring(z.read('word/document.xml'))
    text=' '.join(t.text or '' for t in root.findall('.//w:t',N))
    check('Eight request IDs present in DOCX',all(r['request_id'] in text for r in routes))
    check('Intentional sender placeholders and unsent label retained','[Sender name]' in text and 'NOT SENT' in text)
    rels=ET.fromstring(z.read('word/_rels/document.xml.rels'))
    links=[r.attrib['Target'] for r in rels if r.attrib.get('Type','').endswith('/hyperlink')]
    check('DOCX source hyperlinks resolve to source register',len(links)>=25 and all(u in {r['url'] for r in src.values()} for u in links))
    check('DOCX contains no mailto submission links',not any(u.startswith('mailto:') for u in links))
    check('No tracked document revisions',not root.findall('.//w:ins',N) and not root.findall('.//w:del',N))
with zipfile.ZipFile(ROOT/'Agency_Verification_Response_Tracker_v0_4.xlsx') as z:
    check('XLSX archive integrity',z.testzip() is None)
    shared=[]
    if 'xl/sharedStrings.xml' in z.namelist():
        for si in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('s:si',N):
            shared.append(''.join(t.text or '' for t in si.findall('.//s:t',N)))
    book=ET.fromstring(z.read('xl/workbook.xml'))
    rels={r.attrib['Id']:r.attrib['Target'] for r in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    tabs={}
    for sh in book.findall('s:sheets/s:sheet',N):
        target=rels[sh.attrib['{'+N['r']+'}id']]
        path=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        tabs[sh.attrib['name']]=ET.fromstring(z.read(path))
    expected=['Dashboard','Requests','EXIM records','DFC records','Intake','Matchmaking','DFC supplemental','Questions','Sources']
    check('Nine named workbook sheets in expected order',list(tabs)==expected)
    def cells(name):
        out={}
        for c in tabs[name].findall('.//s:sheetData/s:row/s:c',N):
            v=c.find('s:v',N);value=v.text if v is not None else None
            if c.attrib.get('t')=='s': value=shared[int(value)] if value is not None else None
            elif c.attrib.get('t')=='inlineStr':value=''.join(t.text or '' for t in c.findall('.//s:t',N))
            out[c.attrib['r']]={'value':value,'type':c.attrib.get('t'),'formula':c.find('s:f',N)}
        return out
    def val(c,k):return c.get(k,{}).get('value')
    for agency,name in [('VR-EXIM-01','EXIM records'),('VR-DFC-01','DFC records')]:
        a=[r for r in finance if r['request_id']==agency];c=cells(name)
        check(name+' row IDs preserve original order',all(val(c,f'B{i}')==r['observation_id'] for i,r in enumerate(a,5)))
        check(name+' official IDs stored as exact text',all(val(c,f'C{i}')==r['official_source_record_id'] and c[f'C{i}']['type'] in ('s','inlineStr','str') for i,r in enumerate(a,5)))
        check(name+' all responses unreceived and blank',all(val(c,f'M{i}')=='Not received' and all(val(c,f'{col}{i}') in ('',None) for col in ['N','O','P','Q','R','S','T','U','V']) for i in range(5,5+len(a))))
    for name,n,statuscol,blankcols in [('Intake',113,'I',['J','K','L','M','N','O','P','Q','R','S']),('Matchmaking',12,'I',['J','K','L','M','N','O','P','Q','R','S','T','U','V','W']),('DFC supplemental',162,'M',['N','O','P','Q','R','S','T','U'])]:
        c=cells(name)
        check(name+' response states and editable fields initially blank',all(val(c,f'{statuscol}{i}')=='Not received' and all(val(c,f'{co}{i}') in ('',None) for co in blankcols) for i in range(5,5+n)))
    c=cells('Requests');check('All eight request statuses remain unsent',all(val(c,f'G{i}')=='Draft - not sent' and val(c,f'H{i}') in ('',None) for i in range(5,13)))
    c=cells('Dashboard');targets={'D6':88,'D7':118,'D8':113,'D9':12,'D10':162,'H6':8,'H7':0,'H8':0,'H9':0,'H10':0}
    check('Ten dashboard formulas have correct cached values',all(c[k]['formula'] is not None and float(val(c,k))==v for k,v in targets.items()))
    check('No cached spreadsheet errors',not any(c.attrib.get('t')=='e' for t in tabs.values() for c in t.findall('.//s:c',N)))
    check('No external workbook links, macros or connection definitions',not any('externalLinks/' in n or 'vbaProject' in n or n.endswith('connections.xml') for n in z.namelist()))
    check('Six response/register sheets have validation lists',all(tabs[n].find('s:dataValidations',N) is not None for n in ['Requests','EXIM records','DFC records','Intake','Matchmaking','DFC supplemental']))
    check('All eight record tables have frozen header rows',all(tabs[n].find('.//s:pane',N) is not None for n in expected if n!='Dashboard'))
    check('Eight Excel tables exported',len([p for p in z.namelist() if re.fullmatch(r'xl/tables/table\d+\.xml',p)])==8)
manifest=json.loads((ROOT/'provenance'/'provenance_manifest.json').read_text())
check('All frozen provenance CSV hashes match',all(hashlib.sha256((ROOT/'provenance'/r['path']).read_bytes()).hexdigest()==r['sha256'] for r in manifest['files']))
check('Each of eight standalone drafts exists',all((ROOT/'drafts'/f"{r['request_id']}.txt").is_file() for r in routes))
check('Source and question identifiers remain distinct',not ({r['id'] for r in src.values()} & {r['question_code'] for r in rows('question_bank.csv')}))
# No URL liveness or email delivery is inferred from document hyperlink correctness.
out={'passed':sum(c['passed'] for c in checks),'total':len(checks),'checks':checks,'limits':'Structural checks are not agency verification, URL-liveness tests or mailbox-delivery tests.'}
(ROOT/'validation'/'document_workbook_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'passed':out['passed'],'total':out['total']},indent=2))
